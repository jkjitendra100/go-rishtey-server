import express from "express";
import {
  acceptConnection,
  getConnectionsRequestsFromMe,
  getConnectionRequestsToMe,
  newConnection,
  deleteConnection,
} from "../controllers/connect.js";
import isAuthenticated from "../middlewares/isAuthenticated.js";

const router = express.Router();

router.post("/new", isAuthenticated, newConnection);
router.get("/my/:status", isAuthenticated, getConnectionsRequestsFromMe); // Requests from my side
router.get("/requests", isAuthenticated, getConnectionRequestsToMe); // Requests from user side
router.put("/update", isAuthenticated, acceptConnection);
router.delete("/delete/:receiverId", isAuthenticated, deleteConnection);

export default router;
